﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GUI_V_2.Core.View
{
    class Product
    {
        public string name;

        public string category;

        public string barcode;
    }
}
